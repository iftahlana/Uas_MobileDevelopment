package com.iftah.fomulirhacking_iftah;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.iftah.fomulirhacking_iftah.R;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText ed_nama;
    EditText ed_hp;
    EditText ed_alamat;
    Button bt_diterima;
    TextView tv_hasil;
    Spinner spinnerPilihan;
    String [] pilihanSeminar ={"Mobile", "Desktop", "Website"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed_nama = findViewById(R.id.ed_nama);
        ed_hp = findViewById(R.id.ed_hp);
        ed_alamat = findViewById(R.id.ed_alamat);
        bt_diterima = findViewById(R.id.bt_diterima);
        tv_hasil = findViewById(R.id.tv_hasil);
        spinnerPilihan = findViewById(R.id.spinnerPilihan);

        bt_diterima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (spinnerPilihan.getSelectedItem().toString().equals("Mobile")) {
                    tv_hasil.setText("Syarat Bawa Smartphone");

                }
                else if (spinnerPilihan.getSelectedItem().toString().equals("Desktop")) {
                    tv_hasil.setText("Syarat Bawa Laptop yang ada Netbean");
                }
                else if (spinnerPilihan.getSelectedItem().toString().equals("Website")) {
                    tv_hasil.setText("Syarat Bawa Laptop dan XAMPP");
                }
            }
        });
        ArrayAdapter adapter =new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, pilihanSeminar);
        spinnerPilihan.setAdapter(adapter);
    }

    private void Mobile() {
    }

    private void Desktop() {

    }

    private void Website() {

    }
}
